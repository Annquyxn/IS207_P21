const BannerGrid = () => null;

export default BannerGrid;
