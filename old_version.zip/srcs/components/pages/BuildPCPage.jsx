import BuildPC from '../features/buildPC/BuildPC';

const BuildPCPage = () => {
  return (
    <>
      <BuildPC />
    </>
  );
};

export default BuildPCPage;
